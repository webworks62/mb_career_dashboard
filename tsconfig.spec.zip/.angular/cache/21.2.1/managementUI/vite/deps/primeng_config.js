import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-PMGZFEH7.js";
import "./chunk-S2KJXZRO.js";
import "./chunk-DBGGI7FW.js";
import "./chunk-PYGZ2OYH.js";
import "./chunk-S3TTGUJY.js";
import "./chunk-QF7TIFAG.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-GOMI4DH3.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
